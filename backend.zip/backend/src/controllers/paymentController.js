const crypto = require("crypto");
const Razorpay = require("razorpay");
const Transaction = require("../models/Transaction");

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

const verifyPayment = async (req, res) => {
  try {

    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    } = req.body;

    if (
      !razorpay_order_id ||
      !razorpay_payment_id ||
      !razorpay_signature
    ) {
      return res.status(400).json({
        success: false,
        message: "Missing payment verification data"
      });
    }

    const transaction =
      await Transaction.findOne({
        razorpayOrderId: razorpay_order_id
      });

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: "Transaction not found"
      });
    }

    const body =
      razorpay_order_id +
      "|" +
      razorpay_payment_id;

    const expectedSignature =
      crypto
        .createHmac(
          "sha256",
          process.env.RAZORPAY_KEY_SECRET
        )
        .update(body)
        .digest("hex");

    const isValid =
      expectedSignature === razorpay_signature;

    if (!isValid) {

      transaction.status = "failed";
      transaction.failureReason =
        "Invalid payment signature";

      await transaction.save();

      return res.status(400).json({
        success: false,
        verified: false,
        message:
          "Payment signature verification failed"
      });
    }

    transaction.razorpayPaymentId =
      razorpay_payment_id;

    transaction.status = "captured";

    await transaction.save();

    return res.status(200).json({
      success: true,
      verified: true,
      message: "Payment verified successfully",
      payment: {
        payment_id:
          razorpay_payment_id,

        order_id:
          razorpay_order_id
      }
    });

  } catch (error) {

    console.error(
      "Payment verification error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};


const recordPaymentFailure = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      error_code,
      error_description,
      error_reason,
      error_source,
      error_step,
    } = req.body;

    if (!razorpay_order_id) {
      return res.status(400).json({
        success: false,
        message: "Razorpay order ID is required",
      });
    }

    const transaction =
      await Transaction.findOne({
        razorpayOrderId: razorpay_order_id,
      });

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: "Transaction not found",
      });
    }

    transaction.razorpayPaymentId =
      razorpay_payment_id || null;

    transaction.status = "failed";

    transaction.failureCode =
      error_code || null;

    transaction.failureReason =
      error_reason ||
      error_description ||
      "payment_failed";

    /*
     * Try to fetch the complete payment
     * information from Razorpay.
     *
     * This gives us richer information such as:
     * method, email, contact,
     * error description, error source,
     * error step and error reason.
     */
    if (razorpay_payment_id) {
      try {
        const payment =
          await razorpay.payments.fetch(
            razorpay_payment_id
          );

        transaction.method =
          payment.method || null;

        transaction.email =
          payment.email || null;

        transaction.contact =
          payment.contact || null;

        transaction.failureCode =
          payment.error_code ||
          error_code ||
          null;

        transaction.failureReason =
          payment.error_reason ||
          error_reason ||
          payment.error_description ||
          error_description ||
          "payment_failed";

        console.log(
          "Detailed Razorpay payment fetched:",
          {
            id: payment.id,
            method: payment.method,
            error_code: payment.error_code,
            error_description:
              payment.error_description,
            error_source: payment.error_source,
            error_step: payment.error_step,
            error_reason: payment.error_reason,
          }
        );
      } catch (razorpayError) {
        console.error(
          "Could not fetch detailed Razorpay payment:",
          razorpayError.message
        );

        /*
         * We already received the failure
         * information from Checkout, so don't
         * fail the whole request just because
         * the enrichment call failed.
         */
      }
    }

    await transaction.save();

    console.log(
      "Payment failure recorded:",
      transaction._id
    );

    return res.status(200).json({
      success: true,
      message: "Payment failure recorded",
      transaction,
    });
  } catch (error) {
    console.error(
      "Failure recording error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to record payment failure",
    });
  }
};

module.exports = {
  verifyPayment,
  recordPaymentFailure
};
