const Transaction = require("../models/Transaction");
const AuditLog = require("../models/AuditLog");

const getRecoveryMetrics = async (
  req,
  res
) => {
  try {
    // --------------------------------
    // LIVE DATA ONLY
    // --------------------------------

    const liveFilter = {
      simulation: false,
    };

    // --------------------------------
    // FAILED PAYMENTS
    // --------------------------------

    const failedPayments =
      await Transaction.countDocuments({
        ...liveFilter,
        status: "failed",
      });

    // --------------------------------
    // RECOVERY ATTEMPTS
    // --------------------------------

    const recoveryAttempts =
      await Transaction.countDocuments({
        ...liveFilter,
        recoveryStatus: {
          $in: [
            "ATTEMPTED",
            "RECOVERED",
            "FAILED",
          ],
        },
      });

    // --------------------------------
    // RECOVERED
    // --------------------------------

    const recoveredTransactions =
      await Transaction.countDocuments({
        ...liveFilter,
        recoveryStatus:
          "RECOVERED",
      });

    // --------------------------------
    // STOPPED
    // --------------------------------

    const stoppedTransactions =
      await Transaction.countDocuments({
        ...liveFilter,
        recoveryStatus:
          "STOPPED",
      });

    // --------------------------------
    // ESCALATED
    // --------------------------------

    const escalatedTransactions =
      await Transaction.countDocuments({
        ...liveFilter,
        recoveryStatus:
          "ESCALATED",
      });

    // --------------------------------
    // FAILED RECOVERY
    // --------------------------------

    const failedRecoveryAttempts =
      await Transaction.countDocuments({
        ...liveFilter,
        recoveryStatus:
          "FAILED",
      });

    // --------------------------------
    // RECOVERED REVENUE
    // --------------------------------

    const recoveredRevenueResult =
      await Transaction.aggregate([
        {
          $match: {
            ...liveFilter,
            recoveryStatus:
              "RECOVERED",
          },
        },
        {
          $group: {
            _id: null,
            totalRecovered: {
              $sum: "$recoveredAmount",
            },
          },
        },
      ]);

    // --------------------------------
    // AT-RISK REVENUE
    // --------------------------------

    const atRiskRevenueResult =
      await Transaction.aggregate([
        {
          $match: {
            ...liveFilter,
            status: "failed",
          },
        },
        {
          $group: {
            _id: null,
            totalAtRisk: {
              $sum: "$amount",
            },
          },
        },
      ]);

    // --------------------------------
    // TOTALS
    // --------------------------------

    const totalRecovered =
      recoveredRevenueResult.length >
      0
        ? recoveredRevenueResult[0]
            .totalRecovered
        : 0;

    const totalAtRisk =
      atRiskRevenueResult.length >
      0
        ? atRiskRevenueResult[0]
            .totalAtRisk
        : 0;

    const recoveryRate =
      totalAtRisk > 0
        ? Number(
            (
              (totalRecovered /
                totalAtRisk) *
              100
            ).toFixed(2)
          )
        : 0;

    // --------------------------------
    // LIVE AUDIT LOGS
    // --------------------------------

    const liveTransactionIds =
      await Transaction.find(
        liveFilter
      ).distinct("_id");

    const totalAuditLogs =
      await AuditLog.countDocuments({
        transactionId: {
          $in: liveTransactionIds,
        },
      });

    // --------------------------------
    // RESPONSE
    // --------------------------------

    return res.status(200).json({
      success: true,

      source: "live",

      metrics: {
        failedPayments,

        recoveryAttempts,

        recoveredTransactions,

        failedRecoveryAttempts,

        stoppedTransactions,

        escalatedTransactions,

        totalAtRisk,

        totalRecovered,

        recoveryRate,

        totalAuditLogs,
      },
    });
  } catch (error) {
    console.error(
      "Recovery metrics error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to calculate recovery metrics",
    });
  }
};

module.exports = {
  getRecoveryMetrics,
};