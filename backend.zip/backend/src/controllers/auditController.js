const RecoveryEvent = require("../models/RecoveryEvent");
const Transaction = require("../models/Transaction");

const getAuditLogs = async (req, res) => {
  try {
    // --------------------------------
    // GET LIVE + SYNTHETIC RECOVERY EVENTS
    // --------------------------------

    const events = await RecoveryEvent.find({})
      .populate(
        "transactionId",
        "amount status razorpayPaymentId simulation"
      )
      .sort({
        createdAt: -1,
      })
      .limit(100)
      .lean();

    // --------------------------------
    // CONVERT RECOVERY EVENTS
    // INTO AUDIT-STYLE RECORDS
    // --------------------------------

    const logs = events.map((event) => {
      const details = event.details || {};

      let action = event.eventType;

      if (event.stage === "POLICY_CHECKED") {
        action =
          event.decision === "ALLOW"
            ? "RECOVERY_ALLOWED"
            : "RECOVERY_BLOCKED";
      }

      if (event.stage === "EXECUTED") {
        if (details.success) {
          action = "RECOVERY_EXECUTED";
        } else {
          action = "RECOVERY_FAILED";
        }
      }

      if (event.stage === "COMPLETED") {
        if (
          details.recoveryStatus === "RECOVERED"
        ) {
          action = "RECOVERY_COMPLETED";
        } else if (
          details.recoveryStatus === "ESCALATED"
        ) {
          action = "RECOVERY_ESCALATED";
        } else if (
          details.recoveryStatus === "STOPPED"
        ) {
          action = "RECOVERY_STOPPED";
        } else {
          action = "RECOVERY_COMPLETED";
        }
      }

      const reason =
        details.reason ||
        details.message ||
        details.diagnosis ||
        "Recovery event recorded.";

      return {
        _id: event._id,
        createdAt: event.createdAt,

        action,

        reason,

        actor:
          details.provider ||
          "RECOVERY_AGENT",

        decision:
          event.decision || null,

        stage: event.stage,

        eventType: event.eventType,

        transactionId:
          event.transactionId,

        simulation:
          event.transactionId?.simulation === true,

        details,
      };
    });

    return res.status(200).json({
      success: true,

      source: "recovery_events",

      count: logs.length,

      logs,
    });
  } catch (error) {
    console.error(
      "Audit log error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to fetch audit logs",

      error: error.message,
    });
  }
};

module.exports = {
  getAuditLogs,
};