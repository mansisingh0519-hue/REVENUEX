const Transaction = require("../models/Transaction");

const getTransactions = async (req, res) => {
  try {
    const transactions =
      await Transaction.find({
        simulation: false,
      })
        .sort({
          createdAt: -1,
        })
        .limit(50);

    return res.status(200).json({
      success: true,
      source: "live",
      count: transactions.length,
      transactions,
    });
  } catch (error) {
    console.error(
      "Transaction fetch error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to fetch transactions",
    });
  }
};

module.exports = {
  getTransactions,
};