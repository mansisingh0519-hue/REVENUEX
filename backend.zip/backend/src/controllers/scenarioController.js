const Transaction =
  require("../models/Transaction");

// ========================================
// CREATE CONTROLLED SCENARIO
// ========================================

const createScenario = async (
  req,
  res
) => {
  try {
    const { scenario } = req.body;

    let transactionData;

    let history = [];

    // ========================================
    // HIGH RECOVERY
    // ========================================

    if (
      scenario ===
      "high_recovery"
    ) {
      const email =
        "successful.customer@revenuex.test";

      // --------------------------------------
      // CUSTOMER HISTORY
      // --------------------------------------

      history = Array.from(
        { length: 6 },
        (_, index) => ({
          razorpayOrderId:
            `SIM_HISTORY_HIGH_${Date.now()}_${index}`,

          razorpayPaymentId:
            `SIM_HISTORY_PAY_HIGH_${Date.now()}_${index}`,

          amount: 1000,

          currency: "INR",

          status: "captured",

          method: "upi",

          failureReason: null,

          failureCode: null,

          email,

          contact:
            "+919999999999",

          retryCount: 0,

          lastRecoveryAction:
            null,

          lastRecoveryAt:
            null,

          recoveryStatus:
            "NOT_ATTEMPTED",

          recoveredAmount: 0,

          // IMPORTANT
          simulation: true,
        })
      );

      // --------------------------------------
      // CURRENT FAILED PAYMENT
      // --------------------------------------

      transactionData = {
        razorpayOrderId:
          `SIM_ORDER_HIGH_${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`,

        razorpayPaymentId:
          `SIM_PAY_HIGH_${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`,

        amount: 500,

        currency: "INR",

        status: "failed",

        method: "upi",

        failureReason:
          "payment_failed",

        failureCode:
          "TEMPORARY_FAILURE",

        email,

        contact:
          "+919999999999",

        retryCount: 0,

        lastRecoveryAction:
          null,

        lastRecoveryAt:
          null,

        recoveryStatus:
          "NOT_ATTEMPTED",

        recoveredAmount: 0,

        // IMPORTANT
        simulation: true,
      };
    }

    // ========================================
    // HIGH RISK
    // ========================================

    else if (
      scenario ===
      "high_risk"
    ) {
      transactionData = {
        razorpayOrderId:
          `SIM_ORDER_RISK_${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`,

        razorpayPaymentId:
          `SIM_PAY_RISK_${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`,

        amount: 75000,

        currency: "INR",

        status: "failed",

        method: "card",

        failureReason:
          "payment_failed",

        failureCode:
          "REPEATED_FAILURE",

        email:
          "high.risk@revenuex.test",

        contact:
          "+918888888888",

        retryCount: 3,

        lastRecoveryAction:
          null,

        lastRecoveryAt:
          null,

        recoveryStatus:
          "NOT_ATTEMPTED",

        recoveredAmount: 0,

        simulation: true,
      };
    }

    // ========================================
    // WEAK CUSTOMER
    // ========================================

    else if (
      scenario ===
      "weak_customer"
    ) {
      transactionData = {
        razorpayOrderId:
          `SIM_ORDER_WEAK_${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`,

        razorpayPaymentId:
          `SIM_PAY_WEAK_${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`,

        amount: 500,

        currency: "INR",

        status: "failed",

        method: "netbanking",

        failureReason:
          "payment_failed",

        failureCode:
          "BAD_REQUEST_ERROR",

        email:
          "new.customer@revenuex.test",

        contact:
          "+917777777777",

        retryCount: 0,

        lastRecoveryAction:
          null,

        lastRecoveryAt:
          null,

        recoveryStatus:
          "NOT_ATTEMPTED",

        recoveredAmount: 0,

        simulation: true,
      };
    }

    // ========================================
    // INVALID SCENARIO
    // ========================================

    else {
      return res.status(400).json({
        success: false,

        message:
          "Invalid scenario. Use high_recovery, high_risk, or weak_customer.",
      });
    }

    // ========================================
    // SAVE HISTORY
    // ========================================

    if (history.length > 0) {
      await Transaction.insertMany(
        history
      );
    }

    // ========================================
    // SAVE CURRENT PAYMENT
    // ========================================

    const transaction =
      await Transaction.create(
        transactionData
      );

    console.log(
      "Scenario created:",
      {
        scenario,
        transactionId:
          transaction._id,
        simulation:
          transaction.simulation,
        email:
          transaction.email,
      }
    );

    return res.status(201).json({
      success: true,

      message:
        "Scenario created successfully",

      scenario,

      historyCreated:
        history.length,

      transaction,
    });
  } catch (error) {
    console.error(
      "Scenario creation error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to create scenario",
    });
  }
};

module.exports = {
  createScenario,
};