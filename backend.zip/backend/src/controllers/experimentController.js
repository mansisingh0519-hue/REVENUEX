const ExperimentRun =
  require("../models/ExperimentRun");

const {
  runBatchExperiment,
} = require("../services/experimentService");

// ========================================
// RUN EXPERIMENT
// ========================================

const runExperiment = async (
  req,
  res
) => {
  try {
    const count =
      Number(req.body.count) || 100;

    if (
      count < 1 ||
      count > 500
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Count must be between 1 and 500",
      });
    }

    console.log(
      `Starting ${count}-case REVENUEX experiment...`
    );

    const experiment =
      await runBatchExperiment({
        count,
      });

    const runId =
      `RUN_${Date.now()}_${Math.random()
        .toString(36)
        .slice(2, 8)}`;

    const savedRun =
      await ExperimentRun.create({
        runId,

        totalCases:
          experiment.totalCases,

        totalAtRisk:
          experiment.totalAtRisk,

        eligibleRevenue:
          experiment.eligibleRevenue,

        totalRecovered:
          experiment.totalRecovered,

        recoveryRate:
          experiment.recoveryRate,

        eligibleRecoveryRate:
          experiment.eligibleRecoveryRate,

        recoveryAttempts:
          experiment.recoveryAttempts,

        blockedActions:
          experiment.blockedActions,

        blockedRate:
          experiment.blockedRate,

        escalatedActions:
          experiment.escalatedActions,

        stoppedActions:
          experiment.stoppedActions,

        policyViolations:
          experiment.policyViolations,

        correctDecisions:
          experiment.correctDecisions,

        incorrectDecisions:
          experiment.incorrectDecisions,

        decisionAgreement:
          experiment.decisionAgreement,

        expectedActionSummary:
          experiment.expectedActionSummary,

        actionSummary:
          experiment.actionSummary,

        policySummary:
          experiment.policySummary,

        scenarioSummary:
          experiment.scenarioSummary,

        completedAt:
          new Date(),
      });

    console.log(
      "REVENUEX experiment completed:",
      runId
    );

    return res.status(200).json({
      success: true,

      experiment: {
        ...experiment,

        runId:
          savedRun.runId,

        completedAt:
          savedRun.completedAt,
      },
    });
  } catch (error) {
    console.error(
      "Experiment error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to run experiment",
    });
  }
};

// ========================================
// GET LATEST EXPERIMENT
// ========================================

const getLatestExperiment =
  async (req, res) => {
    try {
      const experiment =
        await ExperimentRun.findOne()
          .sort({
            createdAt: -1,
          });

      if (!experiment) {
        return res.status(404).json({
          success: false,
          message:
            "No experiment runs found",
        });
      }

      return res.status(200).json({
        success: true,
        experiment,
      });
    } catch (error) {
      console.error(
        "Latest experiment error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to fetch latest experiment",
      });
    }
  };

module.exports = {
  runExperiment,
  getLatestExperiment,
};