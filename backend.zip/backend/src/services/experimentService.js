const {
  calculateRecoveryScore,
} = require("./recoveryService");

const {
  analyzePaymentWithAI,
} = require("./aiService");

const {
  evaluateRecoveryPolicy,
} = require("./policyService");

// ========================================
// RUN BATCH EXPERIMENT
// ========================================

const runBatchExperiment = async ({
  count = 100,
}) => {
  const results = [];

  // ========================================
  // OVERALL METRICS
  // ========================================

  let totalAtRisk = 0;
  let eligibleRevenue = 0;
  let totalRecovered = 0;

  let recoveryAttempts = 0;
  let blockedActions = 0;
  let escalatedActions = 0;
  let stoppedActions = 0;

  let policyViolations = 0;

  // ========================================
  // DECISION METRICS
  // ========================================

  let correctDecisions = 0;
  let incorrectDecisions = 0;

  // ========================================
  // ACTION SUMMARY
  // ========================================

  const actionSummary = {
    RETRY: 0,
    REVIEW: 0,
    STOP: 0,
  };

  // ========================================
  // EXPECTED ACTION SUMMARY
  // ========================================

  const expectedActionSummary = {
    RETRY: 0,
    REVIEW: 0,
    STOP: 0,
  };

  // ========================================
  // POLICY SUMMARY
  // ========================================

  const policySummary = {
    ALLOW: 0,
    BLOCK: 0,
  };

  // ========================================
  // SCENARIO SUMMARY
  // ========================================

  const scenarioSummary = {
    high_recovery: {
      cases: 0,
      expectedAction: "RETRY",
      allowed: 0,
      blocked: 0,
      recovered: 0,
      failed: 0,
      correctDecisions: 0,
      incorrectDecisions: 0,
      recoveredAmount: 0,
    },

    weak_customer: {
      cases: 0,
      expectedAction: "REVIEW",
      allowed: 0,
      blocked: 0,
      recovered: 0,
      failed: 0,
      correctDecisions: 0,
      incorrectDecisions: 0,
      recoveredAmount: 0,
    },

    high_risk: {
      cases: 0,
      expectedAction: "STOP",
      allowed: 0,
      blocked: 0,
      recovered: 0,
      failed: 0,
      correctDecisions: 0,
      incorrectDecisions: 0,
      recoveredAmount: 0,
    },

    medium_recovery: {
      cases: 0,
      expectedAction: "REVIEW",
      allowed: 0,
      blocked: 0,
      recovered: 0,
      failed: 0,
      correctDecisions: 0,
      incorrectDecisions: 0,
      recoveredAmount: 0,
    },
  };

  // ========================================
  // DETERMINISTIC DISTRIBUTION
  // ========================================

  const highRecoveryCount =
    Math.round(count * 0.35);

  const weakCustomerCount =
    Math.round(count * 0.35);

  const highRiskCount =
    Math.round(count * 0.20);

  const mediumRecoveryCount =
    count -
    highRecoveryCount -
    weakCustomerCount -
    highRiskCount;

  const scenarios = [];

  for (
    let i = 0;
    i < highRecoveryCount;
    i++
  ) {
    scenarios.push(
      "high_recovery"
    );
  }

  for (
    let i = 0;
    i < weakCustomerCount;
    i++
  ) {
    scenarios.push(
      "weak_customer"
    );
  }

  for (
    let i = 0;
    i < highRiskCount;
    i++
  ) {
    scenarios.push(
      "high_risk"
    );
  }

  for (
    let i = 0;
    i < mediumRecoveryCount;
    i++
  ) {
    scenarios.push(
      "medium_recovery"
    );
  }

  // ========================================
  // PROCESS CASES
  // ========================================

  for (let i = 0; i < count; i++) {
    const scenario = scenarios[i];

    const expectedAction =
      scenarioSummary[scenario]
        .expectedAction;

    scenarioSummary[
      scenario
    ].cases++;

    expectedActionSummary[
      expectedAction
    ]++;

    let amount;
    let method;
    let retryCount;
    let successfulHistory;
    let failedHistory;
    let failureCode;

    // ======================================
    // HIGH RECOVERY
    // ======================================

    if (
      scenario ===
      "high_recovery"
    ) {
      amount = 500;
      method = "upi";
      retryCount = 0;
      successfulHistory = 6;
      failedHistory = 1;
      failureCode =
        "TEMPORARY_FAILURE";
    }

    // ======================================
    // WEAK CUSTOMER
    // ======================================

    else if (
      scenario ===
      "weak_customer"
    ) {
      amount = 500;
      method =
        "netbanking";
      retryCount = 0;
      successfulHistory = 0;
      failedHistory = 1;
      failureCode =
        "BAD_REQUEST_ERROR";
    }

    // ======================================
    // HIGH RISK
    // ======================================

    else if (
      scenario ===
      "high_risk"
    ) {
      amount = 75000;
      method = "card";
      retryCount = 3;
      successfulHistory = 1;
      failedHistory = 5;
      failureCode =
        "REPEATED_FAILURE";
    }

    // ======================================
    // MEDIUM RECOVERY
    // ======================================

    else {
      amount = 2500;
      method = "card";
      retryCount = 1;
      successfulHistory = 3;
      failedHistory = 1;
      failureCode =
        "TEMPORARY_FAILURE";
    }

    // ======================================
    // SYNTHETIC TRANSACTION
    // ======================================

    const transaction = {
      _id:
        `experiment_${i}`,

      amount,

      currency: "INR",

      status: "failed",

      method,

      failureReason:
        "payment_failed",

      failureCode,

      retryCount,

      simulation: true,

      recoveryStatus:
        "NOT_ATTEMPTED",

      recoveredAmount: 0,
    };

    totalAtRisk += amount;

    // ======================================
    // CUSTOMER CONTEXT
    // ======================================

    const customerStats = {
      email:
        `synthetic_${i}@revenuex.test`,

      totalTransactions:
        successfulHistory +
        failedHistory +
        1,

      successfulPayments:
        successfulHistory,

      failedPayments:
        failedHistory + 1,

      totalSuccessfulRevenue:
        successfulHistory *
        1000,

      failureRate:
        Number(
          (
            ((failedHistory + 1) /
              (successfulHistory +
                failedHistory +
                1)) *
            100
          ).toFixed(2)
        ),
    };

    // ======================================
    // RECOVERY SCORE
    // ======================================

    const recovery =
      calculateRecoveryScore(
        transaction,
        customerStats
      );

    // ======================================
    // CONTEXT
    // ======================================

    const context = {
      payment: {
        amount,

        currency: "INR",

        method,

        failureReason:
          "payment_failed",

        failureCode,

        retryCount,
      },

      customer:
        customerStats,

      recovery: {
        score:
          recovery.score,

        riskLevel:
          recovery.riskLevel,

        deterministicRecommendation:
          recovery.recommendedAction,
      },
    };

    // ======================================
    // LOCAL AI
    // ======================================

    const aiDecision =
      await analyzePaymentWithAI(
        context
      );

    const actualAction =
      aiDecision.recommendedAction;

    actionSummary[
      actualAction
    ] =
      (actionSummary[
        actualAction
      ] || 0) + 1;

    // ======================================
    // DECISION AGREEMENT
    // ======================================

    if (
      actualAction ===
      expectedAction
    ) {
      correctDecisions++;

      scenarioSummary[
        scenario
      ].correctDecisions++;
    } else {
      incorrectDecisions++;

      scenarioSummary[
        scenario
      ].incorrectDecisions++;
    }

    // ======================================
    // POLICY
    // ======================================

    const policy =
      evaluateRecoveryPolicy({
        transaction,
        aiDecision,
      });

    if (policy.allowed) {
      policySummary.ALLOW++;

      eligibleRevenue += amount;

      recoveryAttempts++;

      scenarioSummary[
        scenario
      ].allowed++;
    } else {
      policySummary.BLOCK++;

      blockedActions++;

      scenarioSummary[
        scenario
      ].blocked++;

      if (
        actualAction ===
        "REVIEW"
      ) {
        escalatedActions++;
      }

      if (
        actualAction ===
        "STOP"
      ) {
        stoppedActions++;
      }

      if (
        policy.violations &&
        policy.violations.length >
          0
      ) {
        policyViolations++;
      }
    }

    // ======================================
    // SIMULATED OUTCOME
    // ======================================

    let finalStatus =
      "BLOCKED";

    let recoveredAmount = 0;

    if (policy.allowed) {
      if (
        scenario ===
          "high_recovery" ||
        scenario ===
          "medium_recovery"
      ) {
        finalStatus =
          "RECOVERED";

        recoveredAmount =
          amount;

        totalRecovered +=
          amount;

        scenarioSummary[
          scenario
        ].recovered++;

        scenarioSummary[
          scenario
        ].recoveredAmount +=
          amount;
      } else {
        finalStatus =
          "FAILED";

        scenarioSummary[
          scenario
        ].failed++;
      }
    }

    // ======================================
    // RESULT
    // ======================================

    results.push({
      caseNumber:
        i + 1,

      scenario,

      expectedAction,

      actualAction,

      decisionMatch:
        actualAction ===
        expectedAction,

      amount,

      recoveryScore:
        recovery.score,

      riskLevel:
        recovery.riskLevel,

      aiAction:
        actualAction,

      policyDecision:
        policy.decision,

      finalStatus,

      recoveredAmount,
    });
  }

  // ========================================
  // FINAL METRICS
  // ========================================

  const recoveryRate =
    totalAtRisk > 0
      ? Number(
          (
            (totalRecovered /
              totalAtRisk) *
            100
          ).toFixed(2)
        )
      : 0;

  const eligibleRecoveryRate =
    eligibleRevenue > 0
      ? Number(
          (
            (totalRecovered /
              eligibleRevenue) *
            100
          ).toFixed(2)
        )
      : 0;

  const blockedRate =
    count > 0
      ? Number(
          (
            (blockedActions /
              count) *
            100
          ).toFixed(2)
        )
      : 0;

  const decisionAgreement =
    count > 0
      ? Number(
          (
            (correctDecisions /
              count) *
            100
          ).toFixed(2)
        )
      : 0;

  // ========================================
  // RETURN
  // ========================================

  return {
    totalCases: count,

    totalAtRisk,

    eligibleRevenue,

    totalRecovered,

    recoveryRate,

    eligibleRecoveryRate,

    recoveryAttempts,

    blockedActions,

    blockedRate,

    escalatedActions,

    stoppedActions,

    policyViolations,

    correctDecisions,

    incorrectDecisions,

    decisionAgreement,

    expectedActionSummary,

    actionSummary,

    policySummary,

    scenarioSummary,

    results,
  };
};

module.exports = {
  runBatchExperiment,
};