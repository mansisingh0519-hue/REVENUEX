// ========================================
// REVENUEX RECOVERY SCORING ENGINE
// ========================================

const clampScore = (score) => {
  return Math.max(
    0,
    Math.min(100, Math.round(score))
  );
};

// ========================================
// CALCULATE RECOVERY SCORE
// ========================================

const calculateRecoveryScore = (
  transaction,
  customerStats
) => {
  const amount =
    Number(transaction?.amount) || 0;

  const retryCount =
    Number(transaction?.retryCount) || 0;

  const successfulPayments =
    Number(
      customerStats?.successfulPayments
    ) || 0;

  const failedPayments =
    Number(
      customerStats?.failedPayments
    ) || 0;

  const totalTransactions =
    Number(
      customerStats?.totalTransactions
    ) || 0;

  const failureRate =
    Number(
      customerStats?.failureRate
    ) || 0;

  const failureCode =
    transaction?.failureCode || "";

  const method =
    transaction?.method || "";

  // ========================================
  // VERY HIGH RISK
  // ========================================

  if (
    amount > 50000 ||
    retryCount >= 3 ||
    failureCode === "REPEATED_FAILURE"
  ) {
    return {
      score: 15,

      riskLevel: "CRITICAL",

      recommendedAction: "STOP",

      reasons: [
        amount > 50000
          ? "Payment amount is too high for automatic recovery"
          : null,

        retryCount >= 3
          ? "Maximum retry threshold has been reached"
          : null,

        failureCode ===
        "REPEATED_FAILURE"
          ? "Payment has repeated failure history"
          : null,
      ].filter(Boolean),
    };
  }

  // ========================================
  // NO / VERY WEAK CUSTOMER HISTORY
  // ========================================

  if (
    successfulPayments === 0 ||
    totalTransactions <= 1
  ) {
    return {
      score: 35,

      riskLevel: "LOW",

      recommendedAction: "REVIEW",

      reasons: [
        "Customer has insufficient successful payment history",
        "Automatic recovery confidence is limited",
      ],
    };
  }

  // ========================================
  // EXCESSIVE CUSTOMER FAILURE RATE
  // ========================================

  if (
    failureRate >= 60 &&
    successfulPayments <= failedPayments
  ) {
    return {
      score: 30,

      riskLevel: "LOW",

      recommendedAction: "REVIEW",

      reasons: [
        "Customer has a high payment failure rate",
        "Successful payment history is insufficient",
      ],
    };
  }

  // ========================================
  // STRONG CUSTOMER HISTORY
  // ========================================

  if (
    successfulPayments >= 5 &&
    failureRate < 40 &&
    retryCount < 3 &&
    amount <= 5000 &&
    failureCode ===
      "TEMPORARY_FAILURE"
  ) {
    return {
      score: 90,

      riskLevel: "HIGH",

      recommendedAction: "RETRY",

      reasons: [
        "Customer has strong successful payment history",
        "Payment failure appears temporary",
        "Payment amount is within automatic recovery limit",
        "No retry limit has been reached",
      ],
    };
  }

  // ========================================
  // GOOD CUSTOMER BUT NOT STRONG ENOUGH
  // ========================================

  if (
    successfulPayments >= 3 &&
    failureRate < 50 &&
    retryCount < 3 &&
    amount <= 5000
  ) {
    return {
      score: 65,

      riskLevel: "MEDIUM",

      recommendedAction: "REVIEW",

      reasons: [
        "Customer has some successful history",
        "Payment may be recoverable",
        "Additional caution is appropriate",
      ],
    };
  }

  // ========================================
  // TEMPORARY FAILURE
  // ========================================

  if (
    failureCode ===
      "TEMPORARY_FAILURE" &&
    retryCount < 2 &&
    amount <= 5000
  ) {
    return {
      score: 55,

      riskLevel: "MEDIUM",

      recommendedAction: "REVIEW",

      reasons: [
        "Failure may be temporary",
        "Payment remains within recovery amount limits",
        "Customer context does not justify automatic retry",
      ],
    };
  }

  // ========================================
  // DEFAULT
  // ========================================

  return {
    score: clampScore(40),

    riskLevel: "LOW",

    recommendedAction: "REVIEW",

    reasons: [
      "Available payment context does not justify automatic recovery",
    ],
  };
};

module.exports = {
  calculateRecoveryScore,
};