// ========================================
// REVENUEX LOCAL AI SERVICE
// ========================================

// IMPORTANT:
// This file intentionally does NOT call
// OpenAI. It provides deterministic local
// AI simulation so development can continue
// without API credits.

// ========================================
// LOCAL AI ANALYSIS
// ========================================

const analyzePaymentWithAI = async (
  context
) => {
  console.log(
    "Running LOCAL AI simulation - no external API call"
  );

  const recovery =
    context?.recovery || {};

  const payment =
    context?.payment || {};

  const customer =
    context?.customer || {};

  const deterministicRecommendation =
    recovery.deterministicRecommendation;

  // ========================================
  // SAFETY-FIRST ACTION SELECTION
  // ========================================

  let recommendedAction =
    deterministicRecommendation ||
    "REVIEW";

  // Never let local AI automatically
  // retry a clearly unsafe payment.

  if (
    payment.retryCount >= 3 ||
    Number(payment.amount) > 50000 ||
    payment.failureCode ===
      "REPEATED_FAILURE"
  ) {
    recommendedAction = "STOP";
  }

// IMPORTANT:
// Never downgrade a hard STOP to REVIEW.
// Safety conditions always have higher priority.

if (
  recommendedAction !== "STOP" &&
  (
    !customer.successfulPayments ||
    customer.successfulPayments === 0
  )
) {
  recommendedAction = "REVIEW";
}

  // ========================================
  // DIAGNOSIS
  // ========================================

  let diagnosis;

  if (
    recommendedAction ===
    "RETRY"
  ) {
    diagnosis =
      "Payment has strong recovery potential based on customer history and temporary failure context.";
  } else if (
    recommendedAction ===
    "STOP"
  ) {
    diagnosis =
      "Payment presents elevated recovery risk and should not be automatically retried.";
  } else {
    diagnosis =
      "Payment may be recoverable, but available context does not justify automatic recovery.";
  }

  // ========================================
  // REASON
  // ========================================

  let reason;

  if (
    recommendedAction ===
    "RETRY"
  ) {
    reason =
      "Strong successful payment history, low retry count and a recoverable failure pattern support an automated retry.";
  } else if (
    recommendedAction ===
    "STOP"
  ) {
    reason =
      "The payment exceeds safe recovery conditions or has reached a retry/risk threshold.";
  } else {
    reason =
      "Customer history or payment context is insufficient for an automatic recovery action.";
  }

  // ========================================
  // CONFIDENCE
  // ========================================

  let confidence = 0.70;

  if (
    recommendedAction ===
    "RETRY"
  ) {
    confidence = 0.94;
  }

  if (
    recommendedAction ===
    "REVIEW"
  ) {
    confidence = 0.82;
  }

  if (
    recommendedAction ===
    "STOP"
  ) {
    confidence = 0.97;
  }

  // ========================================
  // RETURN STRUCTURED AI DECISION
  // ========================================

  return {
    diagnosis,

    recommendedAction,

    confidence,

    reason,

    provider:
      "local-simulation",
  };
};

module.exports = {
  analyzePaymentWithAI,
};