const Transaction =
  require("../models/Transaction");

const RecoveryEvent =
  require("../models/RecoveryEvent");

const {
  calculateRecoveryScore,
} = require("./recoveryService");

const {
  analyzePaymentWithAI,
} = require("./aiService");

const {
  evaluateRecoveryPolicy,
} = require("./policyService");

const {
  Action,
} = require("./recoveryActionService");

// ========================================
// BUILD CUSTOMER CONTEXT
// ========================================

const buildCustomerStats = async (
  transaction
) => {
  // --------------------------------
  // CUSTOMER EMAIL REQUIRED
  // --------------------------------

  if (!transaction.email) {
    return {
      email: null,
      totalTransactions: 0,
      successfulPayments: 0,
      failedPayments: 0,
      totalSuccessfulRevenue: 0,
      failureRate: 0,
    };
  }

  // --------------------------------
  // IMPORTANT:
  //
  // LIVE transaction
  //    → simulation: false
  //
  // SIMULATED transaction
  //    → simulation: true
  //
  // This prevents synthetic benchmark
  // history from contaminating live data.
  // --------------------------------

  const isSimulation =
    transaction.simulation === true;

  const customerTransactions =
    await Transaction.find({
      email: transaction.email,

      simulation: isSimulation,
    }).sort({
      createdAt: -1,
    });

  // --------------------------------
  // SUCCESSFUL PAYMENTS
  // --------------------------------

  const successfulPayments =
    customerTransactions.filter(
      (item) =>
        item.status === "captured"
    );

  // --------------------------------
  // FAILED PAYMENTS
  // --------------------------------

  const failedPayments =
    customerTransactions.filter(
      (item) =>
        item.status === "failed"
    );

  // --------------------------------
  // TOTAL
  // --------------------------------

  const totalTransactions =
    customerTransactions.length;

  // --------------------------------
  // SUCCESSFUL REVENUE
  // --------------------------------

  const totalSuccessfulRevenue =
    successfulPayments.reduce(
      (total, item) =>
        total + (item.amount || 0),
      0
    );

  // --------------------------------
  // FAILURE RATE
  // --------------------------------

  const failureRate =
    totalTransactions > 0
      ? Number(
          (
            (failedPayments.length /
              totalTransactions) *
            100
          ).toFixed(2)
        )
      : 0;

  return {
    email:
      transaction.email,

    totalTransactions,

    successfulPayments:
      successfulPayments.length,

    failedPayments:
      failedPayments.length,

    totalSuccessfulRevenue,

    failureRate,

    simulation:
      isSimulation,
  };
};

// ========================================
// RUN RECOVERY ORCHESTRATION
// ========================================

const runRecoveryOrchestration =
  async (transactionId) => {
    // ======================================
    // FIND TRANSACTION
    // ======================================

    const transaction =
      await Transaction.findById(
        transactionId
      );

    if (!transaction) {
      throw new Error(
        "Transaction not found"
      );
    }

    // ======================================
    // VALIDATE PAYMENT STATE
    // ======================================

    if (
      transaction.status !==
      "failed"
    ) {
      throw new Error(
        "Recovery orchestration requires a failed payment"
      );
    }

    // ======================================
    // RECOVERY STARTED EVENT
    // ======================================

    await RecoveryEvent.create({
      transactionId:
        transaction._id,

      eventType:
        "RECOVERY_STARTED",

      stage:
        "DETECTED",

      decision: null,

      details: {
        amount:
          transaction.amount,

        paymentId:
          transaction.razorpayPaymentId,

        simulation:
          transaction.simulation === true,
      },
    });

    // ======================================
    // CUSTOMER CONTEXT
    // ======================================

    const customerStats =
      await buildCustomerStats(
        transaction
      );

    console.log(
      "Customer recovery context:",
      {
        email:
          customerStats.email,

        totalTransactions:
          customerStats.totalTransactions,

        successfulPayments:
          customerStats.successfulPayments,

        failedPayments:
          customerStats.failedPayments,

        failureRate:
          customerStats.failureRate,

        simulation:
          customerStats.simulation,
      }
    );

    // ======================================
    // RECOVERY SCORE
    // ======================================

    const recovery =
      calculateRecoveryScore(
        transaction,
        customerStats
      );

    // ======================================
    // ANALYSIS EVENT
    // ======================================

    await RecoveryEvent.create({
      transactionId:
        transaction._id,

      eventType:
        "RECOVERY_DECISION",

      stage:
        "ANALYZED",

      decision:
        recovery.recommendedAction,

      details: {
        score:
          recovery.score,

        riskLevel:
          recovery.riskLevel,

        reasons:
          recovery.reasons,

        customerStats,
      },
    });

    // ======================================
    // AGENT CONTEXT
    // ======================================

    const context = {
      payment: {
        amount:
          transaction.amount,

        currency:
          transaction.currency,

        method:
          transaction.method,

        failureReason:
          transaction.failureReason,

        failureCode:
          transaction.failureCode,

        retryCount:
          transaction.retryCount || 0,
      },

      customer:
        customerStats,

      recovery: {
        score:
          recovery.score,

        riskLevel:
          recovery.riskLevel,

        deterministicRecommendation:
          recovery.recommendedAction,
      },
    };

    // ======================================
    // AI / LOCAL AI
    // ======================================

    const aiDecision =
      await analyzePaymentWithAI(
        context
      );

    // ======================================
    // POLICY
    // ======================================

    const policy =
      evaluateRecoveryPolicy({
        transaction,
        aiDecision,
      });

    // ======================================
    // POLICY EVENT
    // ======================================

    await RecoveryEvent.create({
      transactionId:
        transaction._id,

      eventType:
        "RECOVERY_DECISION",

      stage:
        "POLICY_CHECKED",

      decision:
        policy.decision,

      details: {
        aiAction:
          aiDecision.recommendedAction,

        allowed:
          policy.allowed,

        violations:
          policy.violations,

        blockReasons:
          policy.blockReasons,

        checks:
          policy.checks,
      },
    });

    // ======================================
    // EXECUTE BOUNDED ACTION
    // ======================================

    const execution =
      await executeRecoveryAction({
        transaction,
        aiDecision,
        policy,
      });

    // ======================================
    // FINAL EVENT
    // ======================================

    await RecoveryEvent.create({
      transactionId:
        transaction._id,

      eventType:
        "RECOVERY_COMPLETED",

      stage:
        "COMPLETED",

      decision:
        execution.status,

      details: {
        action:
          aiDecision.recommendedAction,

        recoveredAmount:
          execution.recoveredAmount || 0,

        success:
          execution.success,

        message:
          execution.message,

        recoveryStatus:
          execution.recoveryStatus,
      },
    });

    // ======================================
    // RETURN COMPLETE RESULT
    // ======================================

    return {
      transaction: {
        id:
          transaction._id,

        amount:
          transaction.amount,

        paymentId:
          transaction.razorpayPaymentId,

        retryCount:
          transaction.retryCount || 0,

        recoveryStatus:
          transaction.recoveryStatus,

        recoveredAmount:
          transaction.recoveredAmount || 0,

        simulation:
          transaction.simulation === true,
      },

      customer:
        customerStats,

      recovery,

      aiDecision,

      policy,

      execution,
    };
  };

module.exports = {
  runRecoveryOrchestration,
};