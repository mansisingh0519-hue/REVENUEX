
const AuditLog = require("../models/AuditLog");

// ========================================
// EXECUTE BOUNDED RECOVERY ACTION
// ========================================

const executeRecoveryAction = async ({
  transaction,
  aiDecision,
  policy,
}) => {
  const action =
    aiDecision?.recommendedAction;

  // ========================================
  // HARD SAFETY GATE
  // ========================================

  if (!policy || !policy.allowed) {
    transaction.lastRecoveryAction =
      action || "BLOCK";

    transaction.lastRecoveryAt =
      new Date();

    transaction.recoveredAmount =
      transaction.recoveredAmount || 0;

    if (action === "REVIEW") {
      transaction.recoveryStatus =
        "ESCALATED";
    } else if (action === "STOP") {
      transaction.recoveryStatus =
        "STOPPED";
    } else {
      transaction.recoveryStatus =
        "STOPPED";
    }

    await transaction.save();

    await AuditLog.create({
      transactionId:
        transaction._id,

      action:
        "RECOVERY_BLOCKED",

      actor:
        "POLICY_ENGINE",

      decision:
        "BLOCK",

      reason:
        policy.reason,

      details: {
        simulated:
          transaction.simulation === true,

        aiAction:
          action,

        recoveryStatus:
          transaction.recoveryStatus,

        blockReasons:
          policy.blockReasons || [],

        violations:
          policy.violations || [],
      },
    });

    return {
      success: false,

      status: "BLOCKED",

      message:
        action === "REVIEW"
          ? "Recovery blocked and escalated for review."
          : action === "STOP"
          ? "Recovery blocked and stopped by policy."
          : "Recovery action blocked by policy.",

      recoveredAmount: 0,

      recoveryStatus:
        transaction.recoveryStatus,
    };
  }

  // ========================================
  // HARD PAYMENT STATE CHECK
  // ========================================

  if (
    transaction.status !== "failed"
  ) {
    return {
      success: false,

      status: "BLOCKED",

      message:
        "Payment is no longer in a failed state.",

      recoveredAmount: 0,

      recoveryStatus:
        transaction.recoveryStatus ||
        "STOPPED",
    };
  }

  // ========================================
  // DUPLICATE RECOVERY PROTECTION
  // ========================================

  if (
    transaction.recoveryStatus ===
    "RECOVERED"
  ) {
    return {
      success: false,

      status: "ALREADY_RECOVERED",

      message:
        "Recovery has already been completed for this transaction.",

      recoveredAmount:
        transaction.recoveredAmount || 0,

      recoveryStatus:
        transaction.recoveryStatus,
    };
  }

  // ========================================
  // RETRY ACTION
  // ========================================

  if (action === "RETRY") {
    const currentRetryCount =
      transaction.retryCount || 0;

    transaction.retryCount =
      currentRetryCount + 1;

    transaction.lastRecoveryAction =
      "RETRY";

    transaction.lastRecoveryAt =
      new Date();

    // ======================================
    // SYNTHETIC SIMULATION
    // ======================================

    if (
      transaction.simulation === true
    ) {
      transaction.recoveryStatus =
        "RECOVERED";

      transaction.recoveredAmount =
        transaction.amount;

      await transaction.save();

      await AuditLog.create({
        transactionId:
          transaction._id,

        action:
          "RETRY_PAYMENT",

        actor:
          "RECOVERY_ENGINE",

        decision:
          "SUCCESS",

        reason:
          "Simulated retry succeeded.",

        details: {
          retryCount:
            transaction.retryCount,

          amount:
            transaction.amount,

          simulated: true,
        },
      });

      return {
        success: true,

        status:
          "RECOVERED",

        message:
          "Simulated retry succeeded.",

        recoveredAmount:
          transaction.amount,

        recoveryStatus:
          transaction.recoveryStatus,
      };
    }

    // ======================================
    // LIVE PAYMENT SAFETY
    // ======================================

    /*
     * Real payment retry remains disabled.
     *
     * REVENUEX demonstrates the decision,
     * policy enforcement and bounded execution
     * without automatically moving real money.
     */

    transaction.recoveryStatus =
      "FAILED";

    transaction.recoveredAmount =
      0;

    await transaction.save();

    await AuditLog.create({
      transactionId:
        transaction._id,

      action:
        "RETRY_PAYMENT",

      actor:
        "RECOVERY_ENGINE",

      decision:
        "FAILED",

      reason:
        "Live payment retry is disabled in the current demo environment.",

      details: {
        retryCount:
          transaction.retryCount,

        amount:
          transaction.amount,

        simulated: false,
      },
    });

    return {
      success: false,

      status:
        "FAILED",

      message:
        "Live payment retry is disabled in the current demo environment.",

      recoveredAmount: 0,

      recoveryStatus:
        transaction.recoveryStatus,
    };
  }

  // ========================================
  // UNKNOWN / NON-EXECUTABLE ACTION
  // ========================================

  transaction.lastRecoveryAction =
    action || "UNKNOWN";

  transaction.lastRecoveryAt =
    new Date();

  transaction.recoveryStatus =
    "STOPPED";

  transaction.recoveredAmount =
    transaction.recoveredAmount || 0;

  await transaction.save();

  await AuditLog.create({
    transactionId:
      transaction._id,

    action:
      "RECOVERY_REQUIRES_REVIEW",

    actor:
      "RECOVERY_ENGINE",

    decision:
      "BLOCK",

    reason:
      `Recovery action ${
        action || "UNKNOWN"
      } is not automatically executable.`,

    details: {
      simulated:
        transaction.simulation === true,

      action:
        action || "UNKNOWN",
    },
  });

  return {
    success: false,

    status:
      "BLOCKED",

    message:
      `Recovery action ${
        action || "UNKNOWN"
      } requires review or stopping.`,

    recoveredAmount: 0,

    recoveryStatus:
      transaction.recoveryStatus,
  };
};

module.exports = {
  executeRecoveryAction,
};

