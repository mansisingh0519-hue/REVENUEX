const mongoose = require("mongoose");

const experimentRunSchema =
  new mongoose.Schema(
    {
      runId: {
        type: String,
        required: true,
        unique: true,
      },

      totalCases: {
        type: Number,
        required: true,
      },

      totalAtRisk: {
        type: Number,
        default: 0,
      },

      eligibleRevenue: {
        type: Number,
        default: 0,
      },

      totalRecovered: {
        type: Number,
        default: 0,
      },

      recoveryRate: {
        type: Number,
        default: 0,
      },

      eligibleRecoveryRate: {
        type: Number,
        default: 0,
      },

      recoveryAttempts: {
        type: Number,
        default: 0,
      },

      blockedActions: {
        type: Number,
        default: 0,
      },

      blockedRate: {
        type: Number,
        default: 0,
      },

      escalatedActions: {
        type: Number,
        default: 0,
      },

      stoppedActions: {
        type: Number,
        default: 0,
      },

      policyViolations: {
        type: Number,
        default: 0,
      },

      // --------------------------------
      // DECISION EVALUATION
      // --------------------------------

      correctDecisions: {
        type: Number,
        default: 0,
      },

      incorrectDecisions: {
        type: Number,
        default: 0,
      },

      decisionAgreement: {
        type: Number,
        default: 0,
      },

      expectedActionSummary: {
        type: mongoose.Schema.Types.Mixed,
        default: {},
      },

      actionSummary: {
        type: mongoose.Schema.Types.Mixed,
        default: {},
      },

      policySummary: {
        type: mongoose.Schema.Types.Mixed,
        default: {},
      },

      scenarioSummary: {
        type: mongoose.Schema.Types.Mixed,
        default: {},
      },

      completedAt: {
        type: Date,
        default: Date.now,
      },
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "ExperimentRun",
    experimentRunSchema
  );
  